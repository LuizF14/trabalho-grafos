#ifndef ADJ_MATRIX
#define ADJ_MATRIX

template <typename t, typename w>
class Adj_Matrix {
    private: 

    public:
};

#endif